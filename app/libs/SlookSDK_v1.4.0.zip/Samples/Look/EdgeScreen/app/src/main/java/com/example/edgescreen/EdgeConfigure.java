package com.example.edgescreen;

import android.app.Activity;

public class EdgeConfigure extends Activity {

}
