
package com.example.edgescreen.list;

public class Constants {

    public static final String COCKTAIL_LIST_ADAPTER_CLICK_ACTION = "android.intent.action.COCKTAIL_LIST_ADAPTER_ITEM_CLICK";

    public static final String EXTRA_COCKTAIL_LIST_ADAPTER_COCKTAIL_ID = "CocktailListAdapterCocktailId";

    public static final String EXTRA_CONTENT_INTENT = "contentIntent";
}
